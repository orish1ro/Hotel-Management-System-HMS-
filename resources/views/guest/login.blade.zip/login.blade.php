<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Ragadio Plaza Hotel</title>
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
</head>
<body>

    <header>
        <div class="logo-text">Ragadio Plaza Hotel</div>
        <div class="search-container">
            <input type="text" placeholder="search">
        </div>
        <nav>
            <a href="/">Home</a>
            <a href="/rooms">Rooms</a>
            <a href="/reservations">Reservations</a>
            
            @if(session()->has('guest_id'))
                <a href="/logout">Logout</a>
            @else
                <a href="/login">Login</a>
            @endif
        </nav>
    </header>

    <div class="form-wrapper">
        <div class="form-card">
            
            @if(session('error'))
                <div style="color: #721c24; background-color: #f8d7da; border: 1px solid #f5c6cb; padding: 10px; border-radius: 4px; margin-bottom: 15px; text-align: center; font-size: 14px;">
                    {{ session('error') }}
                </div>
            @endif

            <h2>Login</h2>
            
            <form action="/login-submit" method="POST">
                @csrf
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" required>
                </div>

                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password" required>
                </div>

                <button type="submit" class="btn-submit">Login</button>
            </form>

            <div class="form-footer">
                Don't have an account? <a href="/signup">Sign up here</a>
            </div>
        </div>
    </div>

</body>
</html>