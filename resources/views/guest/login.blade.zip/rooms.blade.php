<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Ragadio Plaza Hotel - Our Rooms</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="{{ asset('css/style.css') }}"> 
</head>
<body>

    <header>
        <div class="logo-text">Ragadio Plaza Hotel</div>
        <div class="search-container">
            <input type="text" placeholder="search">
        </div>
        <nav>
            <a href="/">Home</a>
            <a href="/rooms">Rooms</a>
            <a href="/reservations">Reservations</a>
            
            @if(session()->has('guest_id'))
                <a href="/logout">Logout</a>
            @else
                <a href="/login">Login</a>
            @endif
        </nav>
    </header>

    <div class="rooms-page-container">
        <div class="rooms-title-section">
            <h1>Our Rooms</h1>
            <p>Find the perfect room for your stay.</p>
        </div>

        @if(session('error'))
            <div style="background-color: #f8d7da; color: #721c24; padding: 15px; text-align: center; border-radius: 5px; margin-bottom: 30px; font-weight: bold; border: 1px solid #f5c6cb; max-width: 600px; margin-left: auto; margin-right: auto;">
                ⚠️ {{ session('error') }}
            </div>
        @endif

        @if(session('success'))
            <div style="background-color: #d4edda; color: #155724; padding: 15px; text-align: center; border-radius: 5px; margin-bottom: 30px; font-weight: bold; border: 1px solid #c3e6cb; max-width: 600px; margin-left: auto; margin-right: auto;">
                ✅ {{ session('success') }}
            </div>
        @endif

        <div class="rooms-grid">

            @foreach($rooms as $room)
            <div class="room-card" style="{{ $room->Status != 'Available' ? 'opacity: 0.75;' : '' }}">

                <!-- IMAGE AREA -->
                <div class="room-image-area">
                    @if($room->Picture_Url)
                        <img src="{{ $room->Picture_Url }}" alt="{{ $room->Room_Type }}">
                    @else
                        <div style="width:100%; height:100%; display:flex; align-items:center; justify-content:center; background:#cbd5e1; color:#94a3b8; font-size:14px;">
                            No Image
                        </div>
                    @endif

                    @if($room->Status == 'Available')
                        <span class="status-badge status-Available">Available</span>
                    @else
                        <span class="status-badge status-Booked">Not Available</span>
                    @endif
                </div>

                <!-- ROOM INFO -->
                <div class="room-card-info">
                    <h3>{{ $room->Room_Type }}</h3>
                    <p>{{ $room->Details ?? 'Experience luxury and comfort in our finely appointed rooms.' }}</p>

                    <div style="display:flex; flex-wrap:wrap; gap:8px; margin-top:10px;">
                        @if($room->Inclusions)
                            @foreach(explode(',', $room->Inclusions) as $inclusion)
                                <span style="font-size:13px; color:var(--text-muted);"><i class="fa-solid fa-circle-check" style="color:#10b981;"></i> {{ trim($inclusion) }}</span>
                            @endforeach
                        @else
                            <span style="font-size:13px; color:var(--text-muted);"><i class="fa-solid fa-wifi" style="color:#10b981;"></i> Free Wi-Fi</span>
                            <span style="font-size:13px; color:var(--text-muted);"><i class="fa-solid fa-snowflake" style="color:#10b981;"></i> Aircon</span>
                        @endif
                    </div>

                    @if($room->Status == 'Available')
                        <span class="room-price">₱{{ number_format($room->Price_Per_Night, 2) }} / night</span>
                    @else
                        <span class="room-price" style="color:#ef4444; font-size:16px;">Room Unavailable</span>
                    @endif
                </div>

                <!-- FOOTER / BUTTON -->
                <div class="room-card-footer">
                    @if($room->Status == 'Available')
                        @if(session()->has('guest_id'))
                            <a href="/book/{{ $room->ROOM_ID }}" class="btn-book">Book Now</a>
                        @else
                            <a href="/login" class="btn-book">Book Now</a>
                        @endif
                    @else
                        <button class="btn-book disabled" disabled>Not Available</button>
                    @endif
                </div>

            </div>
            @endforeach

            @if(count($rooms) == 0)
                <div style="grid-column: 1/-1; text-align: center; padding: 50px;">
                    <h3 style="color: var(--text-muted);">No rooms are available at the moment.</h3>
                </div>
            @endif

        </div>
    </div>

    {{-- FOOTER UNCHANGED --}}
    <footer class="footer-container">
        <div class="footer-top">
            <div class="footer-col">
                <h4>Ragadio Plaza</h4>
                <p>Experience luxury and comfort...</p>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <div class="contact-item"><i class="fas fa-envelope"></i> info@ragadioplaza.com</div>
                <div class="contact-item"><i class="fas fa-phone"></i> +63 912 345 6789</div>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="/rooms">Rooms</a>
                <a href="/reservations">Reservations</a>
            </div>
        </div>
        <div class="footer-bottom">
            &copy; 2026 Ragadio Plaza Hotel. All rights reserved.
        </div>
    </footer>
@include('layouts.chat')
</body>
</html>