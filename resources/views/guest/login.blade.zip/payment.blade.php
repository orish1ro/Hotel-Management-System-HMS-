<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Secure Payment - Ragadio Plaza Hotel</title>
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
</head>
<body class="payment-body">

    <div class="receipt-card">

        <div class="receipt-header">
            <h2>Secure Payment</h2>
            <p>Ragadio Plaza Hotel Reservation</p>
        </div>

        <div class="receipt-total">₱{{ number_format($amount, 2) }}</div>

        <div class="receipt-row">
            <span class="label">Room</span>
            <span class="value">{{ $room_type }}</span>
        </div>
        <div class="receipt-row">
            <span class="label">Method</span>
            <span class="value">{{ $payment_method }}</span>
        </div>
        <div class="receipt-row">
            <span class="label">Nights</span>
            <span class="value">{{ $nights }}</span>
        </div>

        <div class="qr-section">[ Scan QR to Pay ]</div>

        <form action="/book-final-submit" method="POST">
            @csrf

            <input type="hidden" name="room_id" value="{{ $room_id }}">
            <input type="hidden" name="check_in" value="{{ $check_in }}">
            <input type="hidden" name="check_out" value="{{ $check_out }}">
            <input type="hidden" name="amount" value="{{ $amount }}">
            <input type="hidden" name="payment_method" value="{{ $payment_method }}">
            <input type="hidden" name="guests" value="{{ request('guests') }}">

            <div class="amount-input-group">
                <label>Enter Amount Paid (₱)</label>
                <input type="number"
                       name="amount_paid"
                       step="0.01"
                       min="{{ $amount }}"
                       value="{{ $amount }}"
                       required
                       placeholder="Enter ₱{{ number_format($amount, 2) }}">
            </div>

            <button type="submit" class="btn-pay">I Have Paid</button>
        </form>

        <a href="/book" class="cancel-link">Cancel Transaction</a>

    </div>

</body>
</html>
