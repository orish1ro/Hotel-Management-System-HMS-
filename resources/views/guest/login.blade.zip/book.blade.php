<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Messages - Ragadio Plaza Hotel</title>
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
</head>
<body>
       <header>
        <div class="logo-text">Ragadio Plaza Hotel</div>
        <div class="search-container">
            <input type="text" placeholder="search">
        </div>
        <nav>
            <a href="/">Home</a>
            <a href="/rooms">Rooms</a>
            <a href="/reservations">Reservations</a>
            
            @if(session()->has('guest_id'))
                <a href="/logout">Logout</a>
            @else
                <a href="/login">Login</a>
            @endif
        </nav>
    </header>

    <div class="booking-page-wrapper">
        <div class="booking-card">

            <h2>Booking Information & Confirmation</h2>
            <p class="subtitle">Please fill in your details to complete your reservation.</p>

            @if ($errors->any())
                <div style="background-color: #f8d7da; color: #721c24; padding: 15px; border-radius: 8px; margin-bottom: 20px; border: 1px solid #f5c6cb;">
                    <strong style="display:block; margin-bottom: 5px;">Please fix the following:</strong>
                    <ul style="margin: 0; padding-left: 20px;">
                        @foreach ($errors->all() as $error)
                            <li style="font-size:14px;">{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <form action="/payment-process" method="POST">
                @csrf

                {{-- GUEST INFORMATION --}}
                <span class="section-label">Guest Information</span>

                <div class="form-group">
                    <label>Full Name</label>
                    <input type="text" name="full_name" placeholder="Juan Dela Cruz" required>
                </div>

                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" placeholder="email@example.com" required>
                </div>

                <div class="form-group">
                    <label>Phone Number</label>
                    <input type="text" name="phone" placeholder="+63 912 345 6789" required>
                </div>

                <div class="form-group">
                    <label>Address</label>
                    <input type="text" name="address" placeholder="City, Country" required>
                </div>

                {{-- RESERVATION DETAILS --}}
                <span class="section-label">Reservation Details</span>

                <div class="form-group">
                    <label>Room Status</label><br>
                    @if($room->Status == 'Available')
                        <span class="status-pill">✓ Available Now</span>
                    @else
                        <span class="status-pill" style="background-color:#fee2e2; color:#991b1b;">✗ Not Available</span>
                    @endif
                </div>

                <div class="form-group">
                    <label>Room Type</label>
                    <input type="text" value="{{ $room->Room_Type }}" readonly>
                    <input type="hidden" name="room_id" value="{{ $room->ROOM_ID }}">
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Check-in Date</label>
                        <input type="date" name="check_in" id="check_in" required>
                    </div>
                    <div class="form-group">
                        <label>Check-out Date</label>
                        <input type="date" name="check_out" id="check_out" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Number of Guests</label>
                        <input type="number" name="guests" value="1" min="1" max="{{ $room->Capacity }}" required>
                        <small style="color: var(--text-muted); font-size: 11px;">Max: {{ $room->Capacity }} guests</small>
                    </div>
                    <div class="form-group">
                        <label>Number of Nights</label>
                        <input type="number" name="nights" id="nights" value="1" min="1" required readonly style="background-color: #f1f5f9; cursor: not-allowed;">
                        <small style="color: var(--text-muted); font-size: 11px;">Auto-calculated from dates</small>
                    </div>
                </div>

                <script>
                    const checkIn  = document.getElementById('check_in');
                    const checkOut = document.getElementById('check_out');
                    const nights   = document.getElementById('nights');

                    // Set minimum check-in date to today
                    const today = new Date().toISOString().split('T')[0];
                    checkIn.setAttribute('min', today);

                    function calculateNights() {
                        const inDate  = new Date(checkIn.value);
                        const outDate = new Date(checkOut.value);
                        if (checkIn.value && checkOut.value && outDate > inDate) {
                            const diff = Math.round((outDate - inDate) / (1000 * 60 * 60 * 24));
                            nights.value = diff;
                        } else {
                            nights.value = 1;
                        }
                    }

                    checkIn.addEventListener('change', function () {
                        // Set check-out min to day after check-in
                        const nextDay = new Date(this.value);
                        nextDay.setDate(nextDay.getDate() + 1);
                        checkOut.setAttribute('min', nextDay.toISOString().split('T')[0]);
                        if (checkOut.value && new Date(checkOut.value) <= new Date(this.value)) {
                            checkOut.value = '';
                            nights.value = 1;
                        }
                        calculateNights();
                    });

                    checkOut.addEventListener('change', calculateNights);
                </script>

                {{-- PAYMENT SUMMARY --}}
                <span class="section-label">Payment Summary</span>

                <div class="payment-summary-box">
                    <p>Room Rate (per night): <strong>₱{{ number_format($room->Price_Per_Night, 2) }}</strong></p>
                    <p class="note">* Total will be calculated on the next secure payment screen based on your number of nights.</p>
                </div>

                {{-- PAYMENT METHOD --}}
                <span class="section-label">Payment Method</span>

                <div class="form-group">
                    <label class="payment-method-label">
                        <input type="radio" name="payment_method" value="E-Money" checked required>
                        E-Money (GCash/PayMaya)
                    </label>
                </div>

                {{-- SUBMIT --}}
                <div style="margin-top: 10px;">
                    @if($room->Status == 'Available')
                        <button type="submit" class="btn-submit">Proceed to Payment</button>
                    @else
                        <button type="button" class="btn-submit" style="background-color: #cbd5e1; color: #94a3b8; cursor: not-allowed;" disabled>Room Unavailable</button>
                    @endif
                </div>

            </form>
        </div>
    </div>
@include('layouts.chat')
</body>
</html>