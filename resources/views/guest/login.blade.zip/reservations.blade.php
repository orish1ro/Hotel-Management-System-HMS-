<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reservations - Ragadio Plaza Hotel</title>
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body>

    <header>
        <div class="logo-text">Ragadio Plaza Hotel</div>
        <div class="search-container">
            <input type="text" placeholder="search">
        </div>
        <nav>
            <a href="/">Home</a>
            <a href="/rooms">Rooms</a>
            <a href="/reservations">Reservations</a>
            
            @if(session()->has('guest_id'))
                <a href="/logout">Logout</a>
            @else
                <a href="/login">Login</a>
            @endif
        </nav>
    </header>
    <main style="padding: 40px 20px; max-width: 900px; margin: 0 auto;">
        
        @if(session('success'))
            <div style="background-color: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin-bottom: 30px; font-weight: bold; border: 1px solid #c3e6cb; text-align: center;">
                ✅ {{ session('success') }}
            </div>
        @endif

        <h1 style="color: #003366; margin-bottom: 5px;">My Reservations</h1>
        <p style="color: #666; margin-bottom: 30px;">View your past and upcoming stays with us.</p>

        @if(count($reservations) > 0)
            <div style="display: flex; flex-direction: column; gap: 20px;">
                @foreach($reservations as $res)
                    <div style="background: white; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); display: flex; overflow: hidden; border: 1px solid #eee;">
                        
                        <div style="width: 250px; background-color: #f4f4f4; background-image: url('{{ asset($res->Picture_Url) }}'); background-size: cover; background-position: center;">
                            @if(!$res->Picture_Url)
                                <div style="display:flex; align-items:center; justify-content:center; height:100%; color:#aaa;">No Image</div>
                            @endif
                        </div>

                        <div style="padding: 20px; flex: 1; display: flex; justify-content: space-between; align-items: center;">
                            <div>
                                <h3 style="margin: 0 0 10px 0; color: #333;">{{ $res->Room_Type }}</h3>
                                <p style="margin: 0 0 5px 0; color: #555; font-size: 14px;">
                                    <strong>Check-in:</strong> {{ \Carbon\Carbon::parse($res->Check_In_Date)->format('M d, Y') }}
                                </p>
                                <p style="margin: 0 0 10px 0; color: #555; font-size: 14px;">
                                    <strong>Check-out:</strong> {{ \Carbon\Carbon::parse($res->Check_Out_Date)->format('M d, Y') }}
                                </p>
                                <p style="margin: 0; color: #003366; font-weight: bold; font-size: 16px;">
                                    Total: ₱{{ number_format($res->Total_Amount, 2) }}
                                </p>
                            </div>

                            <div style="text-align: right;">
                                <div style="margin-bottom: 15px;">
                                    @if($res->Status == 'Pending')
                                        <span style="background-color: #fff3cd; color: #856404; padding: 5px 12px; border-radius: 4px; font-size: 12px; font-weight: bold;">Pending</span>
                                    @elseif($res->Status == 'Confirmed' || $res->Status == 'Booked')
                                        <span style="background-color: #d4edda; color: #155724; padding: 5px 12px; border-radius: 4px; font-size: 12px; font-weight: bold;">Confirmed</span>
                                    @elseif($res->Status == 'Cancelled')
                                        <span style="background-color: #f8d7da; color: #721c24; padding: 5px 12px; border-radius: 4px; font-size: 12px; font-weight: bold;">Cancelled</span>
                                    @elseif($res->Status == 'Checked Out')
                                        <span style="background-color: #cce5ff; color: #004085; padding: 5px 12px; border-radius: 4px; font-size: 12px; font-weight: bold;">Checked Out</span>
                                    @else
                                        <span style="background-color: #e2e3e5; color: #383d41; padding: 5px 12px; border-radius: 4px; font-size: 12px; font-weight: bold;">{{ $res->Status }}</span>
                                    @endif
                                </div>
                                
                                @if($res->PAYMENT_ID)
                                    <a href="/receipt/{{ $res->RESERVATION_ID }}" style="display: inline-block; background-color: #f1c40f; color: #333; padding: 8px 15px; text-decoration: none; font-weight: bold; border-radius: 5px; font-size: 14px; border: 1px solid #d4ac0d;">View Receipt</a>
                                @endif
                            </div>
                        </div>

                    </div>
                @endforeach
            </div>
        @else
            <div style="background: white; padding: 50px; text-align: center; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.05); border: 1px solid #eee;">
                <h3 style="color: #333; margin-bottom: 10px;">You don't have any reservations yet.</h3>
                <p style="color: #666; margin-bottom: 20px;">Ready for a getaway? Explore our luxurious rooms.</p>
                <a href="/rooms" style="display: inline-block; padding: 12px 25px; text-decoration: none; background-color: #f1c40f; color: #333; font-weight: bold; border-radius: 5px; border: 1px solid #d4ac0d;">Browse Rooms</a>
            </div>
        @endif

    </main>
@include('layouts.chat')
</body>
</html>